<?php
$servername = "localhost"; // Host name
$username = "root"; // Mysql username
$password = ""; // Mysql password
$dbName = "adminlogin"; // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbName);

if (!$conn) {
    die("Connection Failed: " . mysqli_connect_error());
}

if (isset($_POST['save'])) {
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_description = $_POST['product_description']; // Fix the variable name here

    $sql_query = "INSERT INTO addcart (product_name, product_price, product_description)
                  VALUES ('$product_name', '$product_price','$product_description')";

    if (mysqli_query($conn, $sql_query)) {
        echo "Details Entry inserted successfully!";
    } else {
        echo "Error: " . $sql_query . mysqli_error($conn);
    }
    mysqli_close($conn);
}

?>
