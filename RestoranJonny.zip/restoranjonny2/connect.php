<!-- Coded by https://beproblemsolver.com  Visit for more such code -->
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "jonnyrestoran";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}