<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart - RestoranJonny</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #333;
            color: #fff;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 10px;
            cursor: pointer;
        }

        button a {
            color: white;
            text-decoration: none;
        }
    </style>
</head>
<body>

    <header>
        <h3>RestoranJonny Reservation</h3>
    </header>

    <table>
        <tr>
            <th>Customer Name</th>
            <th>Phone</th>
            <th>Date</th>
            <th>Time</th>
            <th>Guests</th>
            <th>Action</th>
        </tr>

        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "reservation";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Create and execute query
        $sql = "SELECT * FROM reservation1";
        $result = $conn->query($sql);

        // Check if records were returned
        if ($result->num_rows > 0) {
            // Output data of each row
            while($row = $result->fetch_assoc()) {
                echo '<tr>';
                echo '<td>'.$row["name"].'</td>';
                echo '<td>'.$row["phone"].'</td>';
                echo '<td>'.$row["date"].'</td>';
                echo '<td>'.$row["time"].'</td>';
                echo '<td>'.$row["guests"].'</td>';
                echo '<td><button onclick="deleteRow('.$row["id"].')">Cancel Reservation</button></td>';
                echo '</tr>';
            }



        } else {
            echo "<tr><td colspan='5'>0 results</td></tr>"; // If no record found in the database
        }

        // Close connection
        $conn->close();
        ?>
    </table>

    <p style="text-align: center">
        <button><a href="http://localhost/restoranjonny2/admin_page/adminMenu.php">Back to Main Menu</a></button>
    </p>

    <script>
        function deleteRow(rowId) {
            if (confirm("Are you sure you want to delete this reservation?")) {
                // Redirect to delete script with rowId as a parameter
                window.location.href = "deleteReservation.php?id=" + rowId;
            }
        }
    </script>

</body>
</html>
