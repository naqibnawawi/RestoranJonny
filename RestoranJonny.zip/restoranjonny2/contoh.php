<?php
// Include necessary files and configurations
session_start();

// Check if the user is not logged in, redirect to login page
if (!isset($_SESSION['username'])) {
    header("Location: admin.php");
    exit();
}

// Assuming you have a database connection established
// Replace the placeholder values with your actual database connection details
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "ebook";

$conn = new mysqli('localhost', 'root', '', 'ebook');

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle delete action
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'delete') {
    $deleteId = $_POST['delete_id'];

    // Delete the record from the database
    $deleteSql = "DELETE FROM book WHERE id = '$deleteId'";
    if ($conn->query($deleteSql) === TRUE) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

// Fetch data from your database table
$sql = "SELECT * FROM book";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Home</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            background-color: #333;
            color: #fff;
        }

        table {
            border-collapse: collapse;
            width: 80%;
            margin: 20px auto;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        /* Common button styles */
        .action-button {
            border: none;
            padding: 10px;
            cursor: pointer;
            border-radius: 5px;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin: 5px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        /* Style for the Edit button */
        .edit-button {
            background-color: #f3d250;
            color: #333;
        }

        /* Hover effect for Edit button */
        .edit-button:hover {
            background-color: #ffd700;
        }

        /* Style for the Delete button */
        .delete-button {
            background-color: #ff6666;
            color: #fff;
        }

        /* Hover effect for Delete button */
        .delete-button:hover {
            background-color: #ff3333;
        }

        /* Style for the Add New Book button */
        .add-new-button {
            background-color: #4caf50;
            color: #fff;
            float: right;
        }

        /* Hover effect for Add New Book button */
        .add-new-button:hover {
            background-color: #45a049;
        }
    </style>
    <script>
        // JavaScript function to confirm delete action
        function confirmDelete() {
            return confirm('Are you sure you want to delete this book?');
        }
    </script>
</head>
<body>

<header>
    <h2>Admin Home</h2>
    <a href="admin.php"><button class="action-button logout-button">Logout</button></a>
</header>

<?php
if ($result->num_rows > 0) {
    echo "<table>
            <tr>
                <th>Picture</th>
                <th>Subject</th>
                <th>Type</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td><img src='" . $row["image"] . "' alt='Picture' style='width: 50px; height: 50px;'></td>
                <td>" . $row["subject"] . "</td>
                <td>" . $row["type"] . "</td>
                <td><a href='edit.php?id=".$row["id"]."'><button class='action-button edit-button'>Edit</button></a></td>
                <td>
                    <!-- Delete form with hidden input for book ID -->
                    <form method='post' action='' onsubmit='return confirmDelete();'>
                        <input type='hidden' name='delete_id' value='".$row["id"]."'>
                        <input type='hidden' name='action' value='delete'>
                        <button type='submit' class='action-button delete-button'>Delete</button>
                    </form>
                </td>
              </tr>";
    }

    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
?>

<a href='adminpage.php' class='add-book-button'><button class='action-button add-new-button'>Add New Book</button></a>

</body>
</html>