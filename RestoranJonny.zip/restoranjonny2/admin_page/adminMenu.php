<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main Menu for Admin</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .menu-container {
            text-align: center;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form {
            margin-top: 20px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="menu-container">
        <h1>Main Menu for Admin</h1>

        <form action="competitionList.php" method="post">
            <p><input type="submit" value="View Product" name="cmdView"></p>
        </form>

        <form action="registration.html" method="post">
            <p><input type="submit" value="Update Product" name="cmdSearch"></p>
        </form>

        <form action="deleteList.php" method="post">
            <p><input type="submit" value="Delete Product" name="cmdDelete"></p>
        </form>

        <form action="../contoh1.php" method="post">
            <p><input type="submit" value="Customer Review" name="cmdSearch"></p>           
        </form>

        <form
         action="http://localhost/restoranjonny2/reservation1.php" method="post">
            <p><input type="submit" value="Reservation" name="cmdSearch"></p>           
        </form>


        <form action="login.html" method="post">
    <p><input type="submit" value="Log Out" name="cmdlogout"></p>
</form>

        </form>
    </div>
</body>
</html>
