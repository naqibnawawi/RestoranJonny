<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Creative Multimedia Competition 2020</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        header {
            text-align: center;
            background-color: #3498db;
            padding: 20px;
            color: #fff;
            margin-bottom: 20px;
        }

        section {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 70%;
            max-width: 600px;
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        h3 {
            color: #3498db;
            margin-bottom: 20px;
        }

        input[type="button"] {
            padding: 10px;
            background-color: #3498db;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        input[type="button"]:hover {
            background-color: #2980b9;
        }

        a {
            color: #3498db;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
        <h1>Creative Multimedia Competition 2020</h1>
    </header>

    <section>
        <?php
            $date = date("d-m-Y");
            // get input values from form
            extract($_POST);
        ?>

        <p>Date: <b><?php echo htmlspecialchars($date); ?></b></p>
        <h3>Product Details</h3>
        <table>
            <tr>
                <td>Product</td>
                <td>:</td>
                <td><b><?php echo htmlspecialchars($adName); ?></b></td>
            </tr>
            <tr>
                <td>Price</td>
                <td>:</td>
                <td><b><?php echo htmlspecialchars($adprice); ?></b></td>
            </tr>
            <tr>
                <td>Description</td>
                <td>:</td>
                <td><b><?php echo htmlspecialchars($addesc); ?></b></td>
            </tr>
        </table>

        <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "adminlogin";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // create query using prepared statement
            $stmt = $conn->prepare("INSERT INTO register (adName, adprice, addesc) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $adName, $adprice, $addesc);

            // execute query
            if ($stmt->execute()) {
                echo "<p>New record created successfully</p>";
            } else {
                echo "<p>Error: " . $stmt->error . "</p>";
            }

            // close statement and connection
            $stmt->close();
            $conn->close();
        ?>

        <br>
        <form>
            <input type="button" name="printButton" onClick="window.print()" value="Print">
        </form>

        <p><a href="adminMenu.php">Back to Main Menu</a></p>
    </section>
</body>
</html>
