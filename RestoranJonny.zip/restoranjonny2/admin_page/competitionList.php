<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Creative Multimedia Competition 2020</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        h3 {
            color: #333;
            text-align: center;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ddd;
        }

        th {
            background-color: #333;
            color: #fff;
        }

        a {
            display: inline-block;
            padding: 10px;
            margin: 10px;
            text-decoration: none;
            color: #333;
            border: 1px solid #333;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        a:hover {
            background-color: #333;
            color: #fff;
        }
    </style>
</head>
<body>
    <header>
        <h1>Restorantjonny Update product</h1>
    </header>
    <h3>Registered New Product</h3>

    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "adminlogin";
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    //create and execute query
    $sql = "SELECT * FROM register";
    $result = $conn->query($sql);
    //check if records were returned
    if ($result->num_rows > 0) {
        //create a table to display the record
        echo '<table>';
        echo '<tr><th>Product Name</th><th>Price</th><th>Description</th></tr>';

        // output data of each row
        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . $row["adName"] . '</td>';
            echo '<td>' . $row["adprice"] . '</td>';
            echo '<td>' . $row["addesc"] . '</td>';
            echo '</tr>';
        }
        echo '</table>';
    } else {
        echo "<p>No results found.</p>";
    }
    //close connection
    $conn->close();
    echo '<p><a href="adminMenu.php">Back to Main Menu</a></p>';
    ?>
</body>
</html>
